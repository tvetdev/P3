echo *.txt
