pwd | cat
