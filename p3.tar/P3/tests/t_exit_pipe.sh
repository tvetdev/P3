echo one
exit | echo two
echo three
