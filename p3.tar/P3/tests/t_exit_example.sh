exit | echo hello > foo
