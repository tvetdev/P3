echo b <<
